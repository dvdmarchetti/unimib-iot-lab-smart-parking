var searchData=
[
  ['days_5fper_5fweek_264',['DAYS_PER_WEEK',['../ESPNtpClient_8h.html#a5b1f59cf8d7003f5290096fa5c779952',1,'ESPNtpClient.h']]],
  ['deault_5fnum_5ftimeouts_265',['DEAULT_NUM_TIMEOUTS',['../ESPNtpClient_8h.html#a4ef619f5c28bab05c76dc2f335e0923b',1,'ESPNtpClient.h']]],
  ['default_5fmax_5fresync_5fretry_266',['DEFAULT_MAX_RESYNC_RETRY',['../ESPNtpClient_8h.html#ace41d9ce5500c6f7b41791baafda4f1d',1,'ESPNtpClient.h']]],
  ['default_5fmin_5fsync_5faccuracy_5fus_267',['DEFAULT_MIN_SYNC_ACCURACY_US',['../ESPNtpClient_8h.html#a45f7103ef6735228c626dc9a8547f273',1,'ESPNtpClient.h']]],
  ['default_5fntp_5finterval_268',['DEFAULT_NTP_INTERVAL',['../ESPNtpClient_8h.html#a334756c0679ed27bcc1d694c79d801eb',1,'ESPNtpClient.h']]],
  ['default_5fntp_5fport_269',['DEFAULT_NTP_PORT',['../ESPNtpClient_8h.html#a83c09b39199a43ada5d1994dba0848e3',1,'ESPNtpClient.h']]],
  ['default_5fntp_5fserver_270',['DEFAULT_NTP_SERVER',['../ESPNtpClient_8h.html#af3a1c88fa0be4caebdf7604a9d46d9c4',1,'ESPNtpClient.h']]],
  ['default_5fntp_5fshortinterval_271',['DEFAULT_NTP_SHORTINTERVAL',['../ESPNtpClient_8h.html#ad3134748c38f78387e2bedf441049c0c',1,'ESPNtpClient.h']]],
  ['default_5fntp_5ftimeout_272',['DEFAULT_NTP_TIMEOUT',['../ESPNtpClient_8h.html#a1d7c99136a726e79cfefc05b9bb8ec1c',1,'ESPNtpClient.h']]],
  ['default_5fnum_5foffset_5fave_5frounds_273',['DEFAULT_NUM_OFFSET_AVE_ROUNDS',['../ESPNtpClient_8h.html#acf5fd69598c8c7f555db31dd04a45ae8',1,'ESPNtpClient.h']]],
  ['default_5ftime_5fsync_5fthreshold_274',['DEFAULT_TIME_SYNC_THRESHOLD',['../ESPNtpClient_8h.html#a50b774c40020beee294a92ec525c8aa2',1,'ESPNtpClient.h']]],
  ['delay_275',['delay',['../classNTPClient.html#a6e3201afc55dd0fc3c3cc1ce6875cf09',1,'NTPClient::delay()'],['../structNTPSyncEventInfo__t.html#a420e9615aae8950d88961218f417f7ea',1,'NTPSyncEventInfo_t::delay()']]],
  ['destination_276',['destination',['../structNTPPacket__t.html#ae692986f357410796ec037e81e8ebd45',1,'NTPPacket_t']]],
  ['dispersion_277',['dispersion',['../structNTPPacket__t.html#ae71f63d80b87c39794bc0b5c840f34f0',1,'NTPPacket_t::dispersion()'],['../structNTPSyncEventInfo__t.html#a141a6ef93e3de51f417c2d265403a155',1,'NTPSyncEventInfo_t::dispersion()']]]
];
