var searchData=
[
  ['event_278',['event',['../structNTPEvent__t.html#abd1c33f815f3ef2bf1efb51733fbefee',1,'NTPEvent_t']]]
];
