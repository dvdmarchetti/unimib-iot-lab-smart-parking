var searchData=
[
  ['packetlastreceived_118',['packetLastReceived',['../classNTPClient.html#a8c476e8aaca6ece362ecf722173436b7',1,'NTPClient']]],
  ['partialsync_119',['partialSync',['../ESPNtpClient_8h.html#aeb8b025505183f78dd68c428f897f549a87d93fd5a314e0cddfeb7c1d34522b93',1,'ESPNtpClient.h']]],
  ['partlysync_120',['partlySync',['../NTPEventTypes_8h.html#ab04a3f38407e6839ce1edc75ae02f152ae005825f300d9a2b2d165e90a51a0e27',1,'NTPEventTypes.h']]],
  ['peerstratum_121',['peerStratum',['../structNTPPacket__t.html#ae0b675efa2e93e1edd4e5d07aa058e7c',1,'NTPPacket_t']]],
  ['pollinginterval_122',['pollingInterval',['../structNTPPacket__t.html#aa317717772f4e38ba56b925177ab5b6e',1,'NTPPacket_t']]],
  ['port_123',['port',['../structNTPSyncEventInfo__t.html#a099242535cf89e6d1b7af04654f2d05c',1,'NTPSyncEventInfo_t']]],
  ['processpacket_124',['processPacket',['../classNTPClient.html#a45aa8fb0be0dec2771b76a2c50411e69',1,'NTPClient']]],
  ['processrequesttimeout_125',['processRequestTimeout',['../classNTPClient.html#a55bba0b5a33b16ae6cb4108042e6e8ff',1,'NTPClient']]],
  ['processsyncevent_126',['processSyncEvent',['../advancedExample_8ino.html#a782858657500ca468843899e9c758904',1,'processSyncEvent(NTPEvent_t ntpEvent):&#160;advancedExample.ino'],['../ledFlasher_8ino.html#a782858657500ca468843899e9c758904',1,'processSyncEvent(NTPEvent_t ntpEvent):&#160;ledFlasher.ino'],['../main_8cpp.html#a782858657500ca468843899e9c758904',1,'processSyncEvent(NTPEvent_t ntpEvent):&#160;main.cpp']]]
];
