var searchData=
[
  ['partialsync_361',['partialSync',['../ESPNtpClient_8h.html#aeb8b025505183f78dd68c428f897f549a87d93fd5a314e0cddfeb7c1d34522b93',1,'ESPNtpClient.h']]],
  ['partlysync_362',['partlySync',['../NTPEventTypes_8h.html#ab04a3f38407e6839ce1edc75ae02f152ae005825f300d9a2b2d165e90a51a0e27',1,'NTPEventTypes.h']]]
];
