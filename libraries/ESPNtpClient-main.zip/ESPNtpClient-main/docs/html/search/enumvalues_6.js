var searchData=
[
  ['syncd_365',['syncd',['../ESPNtpClient_8h.html#aeb8b025505183f78dd68c428f897f549aa3159576910c86abc951d94e7d797252',1,'ESPNtpClient.h']]],
  ['syncerror_366',['syncError',['../NTPEventTypes_8h.html#ab04a3f38407e6839ce1edc75ae02f152a86e97631b6120a747c7b8a860d310100',1,'NTPEventTypes.h']]],
  ['syncnotneeded_367',['syncNotNeeded',['../NTPEventTypes_8h.html#ab04a3f38407e6839ce1edc75ae02f152a8bba5d5f0a5f7f7ff540585939493879',1,'NTPEventTypes.h']]]
];
