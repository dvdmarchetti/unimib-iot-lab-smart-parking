var searchData=
[
  ['ntpstatus_354',['NTPStatus',['../ESPNtpClient_8h.html#aeb8b025505183f78dd68c428f897f549',1,'ESPNtpClient.h']]],
  ['ntpsynceventtype_5ft_355',['NTPSyncEventType_t',['../NTPEventTypes_8h.html#ab04a3f38407e6839ce1edc75ae02f152',1,'NTPEventTypes.h']]]
];
