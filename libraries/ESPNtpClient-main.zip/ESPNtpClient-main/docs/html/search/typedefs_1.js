var searchData=
[
  ['onsyncevent_5ft_353',['onSyncEvent_t',['../ESPNtpClient_8h.html#a25d29b56b51da368f8330f94299b6c32',1,'ESPNtpClient.h']]]
];
