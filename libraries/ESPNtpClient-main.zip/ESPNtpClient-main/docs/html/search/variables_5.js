var searchData=
[
  ['info_282',['info',['../structNTPEvent__t.html#ad8c037d8573206772a19e74320daa820',1,'NTPEvent_t']]],
  ['isconnected_283',['isConnected',['../classNTPClient.html#a570e7d514408badb1b2560c92e810685',1,'NTPClient']]]
];
