var searchData=
[
  ['timestamp32_5ft_197',['timestamp32_t',['../structtimestamp32__t.html',1,'']]],
  ['timestamp64_5ft_198',['timestamp64_t',['../structtimestamp64__t.html',1,'']]]
];
