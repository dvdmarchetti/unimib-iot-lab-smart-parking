var searchData=
[
  ['udp_347',['udp',['../classNTPClient.html#a724dbee282a5e07823ef676d5225a634',1,'NTPClient']]],
  ['uptime_348',['uptime',['../classNTPClient.html#a1a32775547e3befdf97a9b3fe0a7fe27',1,'NTPClient']]]
];
