var searchData=
[
  ['packetlastreceived_314',['packetLastReceived',['../classNTPClient.html#a8c476e8aaca6ece362ecf722173436b7',1,'NTPClient']]],
  ['peerstratum_315',['peerStratum',['../structNTPPacket__t.html#ae0b675efa2e93e1edd4e5d07aa058e7c',1,'NTPPacket_t']]],
  ['pollinginterval_316',['pollingInterval',['../structNTPPacket__t.html#aa317717772f4e38ba56b925177ab5b6e',1,'NTPPacket_t']]],
  ['port_317',['port',['../structNTPSyncEventInfo__t.html#a099242535cf89e6d1b7af04654f2d05c',1,'NTPSyncEventInfo_t']]]
];
