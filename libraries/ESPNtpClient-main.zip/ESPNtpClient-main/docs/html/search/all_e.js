var searchData=
[
  ['readme_2emd_127',['readme.md',['../readme_8md.html',1,'']]],
  ['receive_128',['receive',['../structNTPPacket__t.html#a1d7673bb56c21641c0d318fc5283e263',1,'NTPPacket_t']]],
  ['receivertimer_129',['receiverTimer',['../classNTPClient.html#a4bad124820a37328802e1b5c7ff49257',1,'NTPClient']]],
  ['reference_130',['reference',['../structNTPPacket__t.html#aaf545dc284bbb7f905871882e7240a76',1,'NTPPacket_t']]],
  ['refid_131',['refID',['../structNTPPacket__t.html#af309052ae572f15f7c2cc00c61ceefdc',1,'NTPPacket_t']]],
  ['requestsent_132',['requestSent',['../NTPEventTypes_8h.html#ab04a3f38407e6839ce1edc75ae02f152a51e0370b8b68533dc5522a397dd3ee7e',1,'NTPEventTypes.h']]],
  ['responseerror_133',['responseError',['../NTPEventTypes_8h.html#ab04a3f38407e6839ce1edc75ae02f152a044d7bd6ef21be6dee8e32423ca69f7c',1,'NTPEventTypes.h']]],
  ['responsepacketvalid_134',['responsePacketValid',['../classNTPClient.html#a8955c5cfd30a0181d245ee1e3d9d4e8d',1,'NTPClient']]],
  ['responsetimer_135',['responseTimer',['../classNTPClient.html#a504d3373951a9581a2933b3a5f8c8dab',1,'NTPClient']]],
  ['retrials_136',['retrials',['../structNTPSyncEventInfo__t.html#a39831bffb7c7d8760ba0861c531ecbc8',1,'NTPSyncEventInfo_t']]],
  ['rootdelay_137',['rootDelay',['../structNTPPacket__t.html#ac2b05e6f4184dbb9ae8b246192ffc398',1,'NTPPacket_t']]],
  ['round_138',['round',['../classNTPClient.html#a2eb6c34c7f5fb18d160654d1c3baa09c',1,'NTPClient']]]
];
