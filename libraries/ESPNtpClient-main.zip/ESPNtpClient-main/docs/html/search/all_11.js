var searchData=
[
  ['udp_183',['udp',['../classNTPClient.html#a724dbee282a5e07823ef676d5225a634',1,'NTPClient']]],
  ['unsyncd_184',['unsyncd',['../ESPNtpClient_8h.html#aeb8b025505183f78dd68c428f897f549a45299e6794c26d28ebf9dec9e7221de2',1,'ESPNtpClient.h']]],
  ['uptime_185',['uptime',['../classNTPClient.html#a1a32775547e3befdf97a9b3fe0a7fe27',1,'NTPClient']]]
];
