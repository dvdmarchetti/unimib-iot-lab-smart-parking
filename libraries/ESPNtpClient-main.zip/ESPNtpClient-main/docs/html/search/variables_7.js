var searchData=
[
  ['max_5foffset_5faverage_5frounds_289',['MAX_OFFSET_AVERAGE_ROUNDS',['../ESPNtpClient_8h.html#aef0c55f99427089b497d711c1f356f6a',1,'ESPNtpClient.h']]],
  ['maxdispersionerrors_290',['maxDispersionErrors',['../classNTPClient.html#a7416006fb24cce0f8c96b94fa214af12',1,'NTPClient']]],
  ['maxnumsyncretry_291',['maxNumSyncRetry',['../classNTPClient.html#a47b7d0661fc4c7c036f77e0f8c245bdc',1,'NTPClient']]],
  ['min_5fntp_5finterval_292',['MIN_NTP_INTERVAL',['../ESPNtpClient_8h.html#ac6b173ed97582fa3df0b764c9fcf1456',1,'ESPNtpClient.h']]],
  ['min_5fntp_5ftimeout_293',['MIN_NTP_TIMEOUT',['../ESPNtpClient_8h.html#a4225ca4c9809b1c8090f94eec14785e4',1,'ESPNtpClient.h']]],
  ['minsyncaccuracyus_294',['minSyncAccuracyUs',['../classNTPClient.html#a366c8c3eb61ba2ada1e8ad8e368e8f26',1,'NTPClient']]],
  ['mode_295',['mode',['../structNTPFlags__t.html#afefa4829c9695778449968eb49877ed6',1,'NTPFlags_t']]]
];
