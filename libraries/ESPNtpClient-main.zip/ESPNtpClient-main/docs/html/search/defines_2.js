var searchData=
[
  ['ntp_5ftimeout_378',['NTP_TIMEOUT',['../advancedExample_8ino.html#a576b30e69bec539d7c7838cad785b324',1,'NTP_TIMEOUT():&#160;advancedExample.ino'],['../main_8cpp.html#a576b30e69bec539d7c7838cad785b324',1,'NTP_TIMEOUT():&#160;main.cpp']]]
];
