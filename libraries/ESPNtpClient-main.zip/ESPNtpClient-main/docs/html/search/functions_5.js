var searchData=
[
  ['flipint16_217',['flipInt16',['../ESPNtpClient_8cpp.html#a13517d74eb9c1f4403c13782bf4c329f',1,'ESPNtpClient.cpp']]],
  ['flipint32_218',['flipInt32',['../ESPNtpClient_8cpp.html#a004437ce9f8976c43a4453a91718a424',1,'ESPNtpClient.cpp']]]
];
