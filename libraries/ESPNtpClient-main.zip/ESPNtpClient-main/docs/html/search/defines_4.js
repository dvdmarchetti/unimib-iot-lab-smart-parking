var searchData=
[
  ['show_5ftime_5fperiod_380',['SHOW_TIME_PERIOD',['../advancedExample_8ino.html#ac6dbd64c4e02d393694fd33a46630cc9',1,'SHOW_TIME_PERIOD():&#160;advancedExample.ino'],['../basicExample_8ino.html#ac6dbd64c4e02d393694fd33a46630cc9',1,'SHOW_TIME_PERIOD():&#160;basicExample.ino'],['../main_8cpp.html#ac6dbd64c4e02d393694fd33a46630cc9',1,'SHOW_TIME_PERIOD():&#160;main.cpp']]]
];
